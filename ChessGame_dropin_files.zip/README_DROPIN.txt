Ceci est un "drop-in" (fichiers à copier) pour ton projet ChessGame libGDX.

1) Copie les dossiers core/ et lwjgl3/ dans TON projet (en gardant la même arborescence).
   - Si les fichiers existent déjà, remplace-les.

2) IMPORTANT (Java 21):
   Dans le build.gradle à la racine du projet, tout en bas, ajoute:
     subprojects {
         tasks.withType(JavaCompile).configureEach {
             options.release = 21
         }
     }

3) Lancer (dans le dossier du projet, là où il y a gradlew.bat):
     .\gradlew.bat clean
     .\gradlew.bat lwjgl3:run

Notes:
- Les écrans Menu/Options/End sont sans 'uiskin.json' (aucun fichier UI à ajouter).
- Dans GameScreen: touches W = victoire (score 10), L = défaite (score 3), juste pour tester.
